TRADE STATE LAB
Reliable trade history before downstream AI

A small educational demonstrator prepared for Saumya S.'s data-engineering
showcase, with AI assistance. Every event is synthetic. No employer code,
client records, regulatory data or production performance metrics are included.

Run from this folder with Python 3.10+ and SQLite window-function support:
  python trade_state.py
  python -m unittest -v test_trade_state.py

No third-party Python packages, API key, model, cloud service or account is needed.

The business key is (source, trade_id, version). A repeated identical payload
is a replay. Arrival sequence is ingestion metadata, not business precedence.
Highest validated version wins. Active filtering happens after reconstruction.
Conflicting payloads for the same business key quarantine the entire trade,
including when the conflict is in older history. This is an intentionally
conservative example policy, not a universal market-data requirement.

The AI context packet is deterministic JSON. It is NOT an LLM response,
an agent evaluation or evidence that a model will use the packet correctly.
Cancelled states remain explicit. Missing or conflicting evidence is ineligible
for serving. A real AI interface needs separate groundedness and abstention evals.

Notional is integer minor units; only USD and EUR (two decimal places) are
supported. Amounts are never summed across currencies or converted with FX.

Limitations: in-memory snapshot reconstruction; no persistent ingestion service,
transactional checkpoints, production monitoring, multi-source reconciliation,
business-day calendars, full lifecycle coverage or regulatory compliance claim.
Input-order and replay invariance here do not prove exactly-once delivery in a
distributed system. The browser preview is a separate JavaScript implementation
checked against the Python fixture outputs.

The point is to make engineering choices inspectable: late data, cancellations,
replays, conflict policy and provenance all affect what can be trusted downstream.

References:
https://www.sqlite.org/windowfunctions.html
https://docs.python.org/3/library/sqlite3.html
https://airflow.apache.org/docs/apache-airflow/stable/best-practices.html
